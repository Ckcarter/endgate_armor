
package rem.endgate_armor.client.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;

public class EndgatePlateLeggingsModel<T extends net.minecraft.world.entity.LivingEntity> extends HumanoidModel<T> {

    public EndgatePlateLeggingsModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create()
                        .texOffs(0, 32)
                        .addBox(-2.3F, 0.0F, -2.3F, 4.6F, 12.0F, 4.6F)
                        .texOffs(24, 32)
                        .addBox(-1.7F, 1.0F, -2.75F, 3.4F, 9.5F, 0.45F)
                        .texOffs(40, 32)
                        .addBox(-2.0F, 4.6F, -3.0F, 4.0F, 2.2F, 0.6F),
                PartPose.offset(-1.9F, 12.0F, 0.0F)
        );

        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create()
                        .texOffs(0, 48)
                        .addBox(-2.3F, 0.0F, -2.3F, 4.6F, 12.0F, 4.6F)
                        .texOffs(24, 48)
                        .addBox(-1.7F, 1.0F, -2.75F, 3.4F, 9.5F, 0.45F)
                        .texOffs(40, 48)
                        .addBox(-2.0F, 4.6F, -3.0F, 4.0F, 2.2F, 0.6F),
                PartPose.offset(1.9F, 12.0F, 0.0F)
        );

        return LayerDefinition.create(mesh, 64, 64);
    }
}
