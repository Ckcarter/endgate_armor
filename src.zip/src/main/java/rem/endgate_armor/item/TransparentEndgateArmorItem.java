package rem.endgate_armor.item;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

/**
 * Uses a fully transparent vanilla armor texture so the normal armor pass is invisible.
 * The visible effect comes from the custom EndgatePortalArmorLayer.
 */
public class TransparentEndgateArmorItem extends ArmorItem {

    public TransparentEndgateArmorItem(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }

    @Override
    public @Nullable String getArmorTexture(ItemStack stack, Entity entity, net.minecraft.world.entity.EquipmentSlot slot, String type) {
        return "endgate_armor:textures/models/armor/transparent_armor.png";
    }
}
