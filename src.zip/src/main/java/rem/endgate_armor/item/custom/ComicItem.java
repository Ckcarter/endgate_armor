package rem.endgate_armor.item.custom;

public class ComicItem {
}
