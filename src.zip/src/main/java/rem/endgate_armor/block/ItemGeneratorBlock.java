package rem.endgate_armor.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;
import rem.endgate_armor.block.entity.ItemGeneratorBlockEntity;
import rem.endgate_armor.registry.ModBlockEntities;

public class ItemGeneratorBlock extends BaseEntityBlock {

    public ItemGeneratorBlock(Properties properties) {
        super(properties);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ItemGeneratorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        return createTickerHelper(type, ModBlockEntities.ITEM_GENERATOR.get(), ItemGeneratorBlockEntity::serverTick);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof ItemGeneratorBlockEntity generator) {
                int secondsLeft = Math.max(0, (generator.getMaxProgress() - generator.getProgress()) / 20);
                player.displayClientMessage(Component.literal(
                        "Gold Machine: "
                                + generator.getEnergyStored() + "/" + generator.getMaxEnergyStored() + " FE, "
                                + secondsLeft + " seconds until next gold ingot."
                ), true);
            }
        }

        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
