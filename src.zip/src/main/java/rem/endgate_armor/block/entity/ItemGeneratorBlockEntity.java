package rem.endgate_armor.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.EnergyStorage;
import net.minecraftforge.energy.IEnergyStorage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rem.endgate_armor.registry.ModBlockEntities;

public class ItemGeneratorBlockEntity extends BlockEntity {

    // 20 minutes at 20 ticks per second.
    public static final int GENERATE_TIME_TICKS = 20 * 60 * 20;

    public static final int ENERGY_CAPACITY = 100_000;
    public static final int MAX_RECEIVE = 1_000;
    public static final int ENERGY_PER_GOLD = 10_000;

    private int progress = 0;

    private final EnergyStorage energy = new EnergyStorage(ENERGY_CAPACITY, MAX_RECEIVE, 0) {
        @Override
        public int receiveEnergy(int maxReceive, boolean simulate) {
            int received = super.receiveEnergy(maxReceive, simulate);
            if (received > 0 && !simulate) {
                setChanged();
            }
            return received;
        }
    };

    private LazyOptional<IEnergyStorage> energyOptional = LazyOptional.of(() -> energy);

    public ItemGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ITEM_GENERATOR.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ItemGeneratorBlockEntity generator) {
        if (level.isClientSide) return;

        // The machine only counts down while it has enough power for the next ingot.
        if (generator.energy.getEnergyStored() < ENERGY_PER_GOLD) {
            return;
        }

        generator.progress++;

        if (generator.progress >= GENERATE_TIME_TICKS) {
            generator.progress = 0;
            generator.energy.extractEnergy(ENERGY_PER_GOLD, false);
            generator.dropGold(level, pos);
            generator.setChanged();
        }
    }

    private void dropGold(Level level, BlockPos pos) {
        ItemStack gold = new ItemStack(Items.GOLD_INGOT, 1);
        ItemEntity itemEntity = new ItemEntity(
                level,
                pos.getX() + 0.5D,
                pos.getY() + 1.1D,
                pos.getZ() + 0.5D,
                gold
        );
        itemEntity.setDeltaMovement(0.0D, 0.08D, 0.0D);
        level.addFreshEntity(itemEntity);
    }

    public int getProgress() {
        return progress;
    }

    public int getMaxProgress() {
        return GENERATE_TIME_TICKS;
    }

    public int getEnergyStored() {
        return energy.getEnergyStored();
    }

    public int getMaxEnergyStored() {
        return energy.getMaxEnergyStored();
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        progress = tag.getInt("Progress");
        energy.deserializeNBT(tag.get("Energy"));
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Progress", progress);
        tag.put("Energy", energy.serializeNBT());
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        energyOptional.invalidate();
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        energyOptional = LazyOptional.of(() -> energy);
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> capability, @Nullable Direction side) {
        if (capability == ForgeCapabilities.ENERGY) {
            return energyOptional.cast();
        }
        return super.getCapability(capability, side);
    }
}
